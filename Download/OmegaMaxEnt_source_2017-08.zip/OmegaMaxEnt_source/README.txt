
OmegaMaxEnt : analytic continuation of numerical Matsubara data.


1) To run OmegaMaxEnt, you need Python [https://www.python.org/downloads/] with the Matplotlib package installed [http://matplotlib.org/users/installing.html]. Also make sure you have version 4.8, or higher, of the GNU Compiler Collection (gcc) and BLAS and LAPACK installed (Linux), or the most recent version of Xcode compatible with your system (Mac).

3) Extract the file armadillo-5.600.2.tar.gz (tar zxf armadillo-5.600.2.tar.gz) in the OmegaMaxEnt source code directory. There seems to be an incompatibility with more recent versions of armadillo [http://arma.sourceforge.net]. This will be investigated, but for now, please use that version.

4) Copy the makefile from the directory corresponding to your system (OSX or Linux) to the source code directory and execute the command "make"

5) If the executable file OmegaMaxEnt was created successfully, execute it. If the program works well, 6 figures should open after a few seconds, one with the title "Spectrum at optimal alpha", with five curves plotted, four of which almost identical. Close all the figures and enter any letter other than 'y' in the terminal.
