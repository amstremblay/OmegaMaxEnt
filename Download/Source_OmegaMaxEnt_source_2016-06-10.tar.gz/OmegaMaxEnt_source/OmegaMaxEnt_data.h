/*
 file OmegaMaxEnt_data.h
 definition of class "OmegaMaxEnt_data", the main class of the program OmegaMaxEnt that performs the analytic continuation of numerical Matsubara Green and correlation functions.
 (other source files: OmegaMaxEnt_data.cpp, OmegaMaxEnt_main.cpp, graph_2D.h, graph_2D.cpp, generique.h, generique.cpp)
 
 Copyright (C) 2015 Dominic Bergeron (dominic.bergeron@usherbrooke.ca)
 
 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
 
 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef OMEGAMAXENT_DATA_H
#define OMEGAMAXENT_DATA_H

#include "includeDef.h"
#include <string>
#include <list>
#include <vector>
#include <map>
#include <stdio.h>
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <ctime>
#include "armadillo"
#include "graph_2D.h"
#include "generique.h"
#include "OmegaMaxEnt_license.h"
//#include <QDateTime>
//#include <QFileInfo>

using namespace arma;

//MAIN INPUT FILE PARAMETERS

static string data_file_param("data file:");

enum Data_params_name {BOSON, TAU_GF, TEM, G_INF_FINITE, G_INF, NORM_A, M_1, ERR_M1, M_2, ERR_M2, M_3, ERR_M3, TRUNC_FREQ};

static map<Data_params_name, string> Data_params( {	{BOSON,"bosonic data (yes/[no]):"},
	{TAU_GF,"imaginary time data (yes/[no]):"},
	{TEM,"temperature (in energy units, k_B=1):"},
	{G_INF_FINITE,"finite value at infinite frequency (yes/[no]):"},
	{G_INF,"value at infinite frequency:"},
	{NORM_A,"norm of spectral function:"},
	{M_1,"1st moment:"},
	{ERR_M1,"1st moment error:"},
	{M_2,"2nd moment:"},
	{ERR_M2,"2nd moment error:"},
	{M_3,"3rd moment:"},
	{ERR_M3,"3rd moment error:"},
	{TRUNC_FREQ,"truncation frequency:"}} );

enum Intput_files_params_name {INPUT_DIR, COL_GR, COL_GI, ERROR_FILE, COL_ERR_GR, COL_ERR_GI, COVAR_RE_RE_FILE, COVAR_IM_IM_FILE, COVAR_RE_IM_FILE, COL_G_TAU, COL_ERR_G_TAU, COVAR_TAU_FILE};

static map<Intput_files_params_name, string> Input_files_params( { {INPUT_DIR, "input directory:"},
	{COL_GR, "Re(G) column in data file (default: 2):"},
	{COL_GI, "Im(G) column in data file (default: 3):"},
	{ERROR_FILE, "error file:"},
	{COL_ERR_GR, "Re(G) column in error file (default: 2):"},
	{COL_ERR_GI, "Im(G) column in error file (default: 3):"},
	{COVAR_RE_RE_FILE, "re-re covariance file:"},
	{COVAR_IM_IM_FILE, "im-im covariance file:"},
	{COVAR_RE_IM_FILE, "re-im covariance file:"},
	{COL_G_TAU, "column of G(tau) in data file (default: 2):"},
	{COL_ERR_G_TAU, "column of G(tau) error in error file (default: 2):"},
	{COVAR_TAU_FILE, "imaginary time covariance file:"} } );


enum Grig_params_name {CUTOFF_WN, SPECTR_FUNC_WIDTH, SPECTR_FUNC_CENTER, W_ORIGIN, STEP_W, GRID_W_FILE, NON_UNIFORM_GRID, USE_GRID_PARAMS, PARAM_GRID_PARAMS};

static map<Grig_params_name, string> Grid_params( { {CUTOFF_WN, "Matsubara frequency cutoff (in energy units, k_B=1):"},
	{SPECTR_FUNC_WIDTH, "spectral function width:"},
	{SPECTR_FUNC_CENTER, "spectral function center:"},
	{W_ORIGIN, "real frequency grid origin:"},
	{STEP_W, "real frequency step:"},
	{GRID_W_FILE, "real frequency grid file:"},
	{NON_UNIFORM_GRID,"use non uniform grid in main spectral range (yes/[no]):"},
	{USE_GRID_PARAMS, "use parameterized real frequency grid (yes/[no]):"},
	{PARAM_GRID_PARAMS, "grid parameters (w_0 dw_0 w_1 dw_1 ... w_{N-1} dw_{N-1} w_N):"} } );


enum Preproc_comp_params_name {EVAL_MOMENTS, MAX_M, DEFAULT_MODEL_CENTER, DEFAULT_MODEL_WIDTH, DEFAULT_MODEL_SHAPE, DEFAULT_MODEL_FILE, INIT_SPECTR_FUNC_FILE};
//, INTERP_TYPE
//PEAKED_DEFAULT_MODEL,
static map<Preproc_comp_params_name, string> Preproc_comp_params( { {EVAL_MOMENTS, "evaluate moments (yes/[no]):"},
	{MAX_M, "maximum moment:"},
	{DEFAULT_MODEL_CENTER, "default model center (default: 1st moment):"},
	{DEFAULT_MODEL_WIDTH, "default model half width (default: standard deviation):"},
	{DEFAULT_MODEL_SHAPE, "default model shape parameter (default: 2):"},
	{DEFAULT_MODEL_FILE, "default model file:"},
	{INIT_SPECTR_FUNC_FILE, "initial spectral function file:"} } );
//{INTERP_TYPE, "interpolation type (spline (default), quad, lin):"}
//	{PEAKED_DEFAULT_MODEL, "use peaked default model (yes/no):"},

enum Preproc_exec_params_name {PREPROSSESS_ONLY, DISPL_PREP_FIGS, DISPL_ADV_PREP_FIGS, PRINT_OTHER_PARAMS};

static map<Preproc_exec_params_name, string> Preproc_exec_params( { {PREPROSSESS_ONLY, "preprocess only (yes/[no]):"},
	{DISPL_PREP_FIGS, "display preprocessing figures (yes/[no]):"},
	{DISPL_ADV_PREP_FIGS, "display advanced preprocessing figures (yes/[no]):"},
	{PRINT_OTHER_PARAMS, "print other parameters (yes/[no]):"} } );


enum Output_files_params_name {OUTPUT_DIR, OUTPUT_NAME_SUFFIX, ALPHA_SAVE_MAX, ALPHA_SAVE_MIN, W_SAMPLE};
//, SAVE_A_OPT_ONLY

static map<Output_files_params_name, string> Output_files_params( { {OUTPUT_DIR, "output directory:"},
	{OUTPUT_NAME_SUFFIX, "output file names suffix:"},
	{ALPHA_SAVE_MAX, "maximum alpha for which results are saved:"},
	{ALPHA_SAVE_MIN, "minimum alpha for which results are saved:"},
	{W_SAMPLE, "spectral function sample frequencies (w_1 w_2 ... w_N):"} } );
//{ALPHA_SAVE, "alpha value below which all spectral functions are saved:"},
//{SAVE_A_OPT_ONLY, "save only optimal spectrum (yes/[no]):"}


enum Optim_comp_params_name {ALPHA_INIT, ALPHA_MIN, ALPHA_OPT_MAX, ALPHA_OPT_MIN};
//CHI2_ALPHA_SMOOTH_RANGE

static map<Optim_comp_params_name, string> Optim_comp_params( { {ALPHA_INIT, "initial value of alpha:"},
	{ALPHA_MIN, "minimum value of alpha:"},
	{ALPHA_OPT_MAX, "maximum optimal alpha:"},
	{ALPHA_OPT_MIN, "minimum optimal alpha:"} } );
//{CHI2_ALPHA_SMOOTH_RANGE, "chi2 vs alpha smoothing range in log10 scale:"}

enum Optim_exec_params_name {N_ALPHA, INITIALIZE_MAXENT, INITIALIZE_PREPROC, INTERACTIVE_MODE};

static map<Optim_exec_params_name, string> Optim_exec_params( { {N_ALPHA, "number of values of alpha computed in one execution:"},
	{INITIALIZE_MAXENT, "initialize maxent (yes/[no]):"},
	{INITIALIZE_PREPROC, "initialize preprocessing (yes/[no]):"},
	{INTERACTIVE_MODE, "interactive mode ([yes]/no):"} } );


enum Optim_displ_params_name {PRINT_ALPHA, SHOW_OPTIMAL_ALPHA_FIGS, SHOW_LOWEST_ALPHA_FIGS, SHOW_ALPHA_CURVES, REF_SPECTR_FILE};
//DISPL_OPTIM_FIGS,

static map<Optim_displ_params_name, string> Optim_displ_params( { {PRINT_ALPHA, "print results at each value of alpha (yes/[no]):"},
	{SHOW_OPTIMAL_ALPHA_FIGS,"show optimal alpha figures ([yes]/no):"},
	{SHOW_LOWEST_ALPHA_FIGS,"show lowest alpha figures ([yes]/no):"},
	{SHOW_ALPHA_CURVES,"show alpha dependant curves ([yes]/no):"},
	{REF_SPECTR_FILE, "reference spectral function file:"} } );
//{DISPL_OPTIM_FIGS, "display minimization figures (yes/[no]):"},

// OTHER PARAMETERS

enum Other_params_int_name {NN_MAX, NW_MIN, NW_MAX, NN_FIT_MAX, NN_FIT_FIN, NN_AS_MIN, N_ITER_DA_MAX, NW_SAMP};
//NWN_TEST_METAL, N_ALPHA_MAX_FIGS,

static map<Other_params_int_name, string> Other_params_int( { {NN_MAX,"Nn_max, maximum number of Matsubara frequencies:"},
    {NW_MIN,"Nw_min, minimum number of real frequencies:"},
    {NW_MAX,"Nw_max, maximum number of real frequencies:"},
    {NN_FIT_MAX,"Nn_fit_max, initial maximum number of frequencies used to fit the asymptotic form during computation of moments:"},
    {NN_FIT_FIN,"Nn_fit_fin, final maximum number of frequencies used to fit the asymptotic form during computation of moments:"},
	{NN_AS_MIN,"Nn_as_min, minimum number of frequencies in the asymptotic region:"},
    {N_ITER_DA_MAX,"Niter_dA_max, maximum number of iterations in Newton's method for a given value of alpha:"},
    {NW_SAMP,"Nwsamp, default number of sample frequencies of spectral function to be save as a function of alpha:"} } );
//{NWN_TEST_METAL,"Nwn_test_metal, number of frequencies used to decide if searching for low frequency peak:"},
//{N_ALPHA_MAX_FIGS,"Nalpha_max_figs, maximum number of spectra displayed in one execution:"},

static map<Other_params_int_name, int> Other_params_int_default_values( { {NN_MAX,500},
    {NW_MIN,50},
    {NW_MAX,800},
    {NN_FIT_MAX,200},
    {NN_FIT_FIN,300},
	{NN_AS_MIN,10},
    {N_ITER_DA_MAX,20},
    {NW_SAMP,11} } );
//{NWN_TEST_METAL,10}, {N_ALPHA_MAX_FIGS,20},

enum Other_params_fl_name {F_SW_STD_OMEGA, F_W_RANGE, RMIN_SW_DW, TOL_TEM, TOL_GINF, TOL_NORM, TOL_M1, TOL_M2, TOL_M3, DEFAULT_ERROR_G, ERR_NORM, DEFAULT_ERROR_M, TOL_MEAN_C1,TOL_STD_C1, TOL_RDW, RMIN_DW_DW, RDW_MAX, RW_GRID, RWD_GRID,  MIN_DEF_M, F_ALPHA_INIT, R_WIDTH_ASMIN, F_SMIN, DIFF_CHI2_MAX, TOL_INT_DA, R_C2_H, F_C2, POW_ALPHA_STEP_INIT, POW_ALPHA_STEP_MIN, CHI2_ALPHA_SMOOTH_RANGE_2, F_SCALE_LALPHA_LCHI2, FN_FIT_TAU_W, STD_NORM_PEAK_MAX, VAR_M2_PEAK_MAX, PEAK_WEIGHT_MIN, RMAX_DLCHI2_LALPHA, F_ALPHA_MIN, SAVE_ALPHA_RANGE, R_PEAK_WIDTH_DW, R_WNCUTOFF_WR, R_DW_DW, R_SW_WR, R_WMAX_WR_MIN};
//R_D2G_CHI_PEAK, TOL_R_G0_BETA, TOL_QUAD, F_CHI2_SAVE, F_CHI2_MIN, F_WIDTH_GRID_DENS,

static map<Other_params_fl_name, string> Other_params_fl( { {F_SW_STD_OMEGA, "f_SW_std_omega, ratio of main spectral range and standard deviation of spectrum:"},
	{F_W_RANGE,"f_w_range, total real frequency range=f_w_range*(spectral function width):"},
	{RMIN_SW_DW, "Rmin_SW_dw, minimum ratio of standard deviation and frequency step:"},
    {TOL_TEM,"tol_tem, relative tolerance between temperature extracted from Matsubara frequency and input temperature:"},
	{TOL_GINF,"tol_Ginf, tolerance on frequency-independant part of data:"},
    {TOL_NORM,"tol_norm, tolerance on norm extracted from high frequency:"},
    {TOL_M1,"tol_M1, tolerance between 1st moment extracted from high frequency and input one:"},
    {TOL_M2,"tol_M2, tolerance between 2nd moment extracted from high frequency and input one:"},
    {TOL_M3,"tol_M3, tolerance between 3rd moment extracted from high frequency and input one:"},
    {DEFAULT_ERROR_G,"default_error_G, default error on the input data:"},
    {ERR_NORM,"err_norm, relative error on norm:"},
    {DEFAULT_ERROR_M,"default_error_M, default error on moments:"},
    {TOL_MEAN_C1,"tol_mean_C1, tolerance on mean(M0(n)):"},
    {TOL_STD_C1,"tol_std_C1, tolerance on std(M0(n)):"},
    {TOL_RDW,"tol_rdw, tolerance on ratio of consecutive frequency step:"},
    {RMIN_DW_DW,"Rmin_Dw_dw, minimum number of steps in a grid interval:"},
    {RDW_MAX,"Rdw_max, maximum ratio of steps in consecutive grid interval:"},
    {RW_GRID,"RW_grid, grid interval vs transition region ratio:"},
    {RWD_GRID,"RWD_grid, transition region vs width parameter ratio:"},
    {MIN_DEF_M,"minDefM, minimum value of default model:"},
    {F_ALPHA_INIT,"f_alpha_init, initial ratio of entropy and chi2 contributions to the spectrum:"},
    {R_WIDTH_ASMIN,"R_width_ASmin, width of the minimum entropy spectrum relative to spectral function width:"},
    {F_SMIN,"f_Smin, minimum entropy term versus optimal chi2 ratio:"},
    {DIFF_CHI2_MAX,"diff_chi2_max, maximum relative difference between the chi2 of consecutive values of alpha:"},
    {TOL_INT_DA,"tol_int_dA, tolerance on consecutive values of the integral of |dA| in Newton's method:"},
    {R_C2_H,"rc2H, maximum ratio of the penalization parameter and the maximum eigenvalue of the hessian of chi2:"},
    {F_C2,"fc2, ratio of the default model and the minimum of the penalization function:"},
    {POW_ALPHA_STEP_INIT,"pow_alpha_step_init, initial value of the step in log_10(alpha):"},
    {POW_ALPHA_STEP_MIN,"pow_alpha_step_min, minimum value of the step in log_10(alpha):"},
    {CHI2_ALPHA_SMOOTH_RANGE_2,"chi2_alpha_smooth_range, chi2 vs alpha smoothing range in log10 scale:"},
    {F_SCALE_LALPHA_LCHI2,"f_scale_lalpha_lchi2, log(alpha) scale factor with respect to log(chi2) in the curvature calculation:"},
    {FN_FIT_TAU_W, "FNfitTauW, factor to determine the number of values of tau in the polynomial fit:"},
    {STD_NORM_PEAK_MAX,"std_norm_peak_max, relative tolerance for standard deviation of low frequency peak weight:"},
    {VAR_M2_PEAK_MAX,"varM2_peak_max, relative tolerance on low frequency peak variance:"},
	{PEAK_WEIGHT_MIN, "peak_weight_min, minimum value of peak weight to assume a low energy peak is present:"},
	{RMAX_DLCHI2_LALPHA,"RMAX_dlchi2_lalpha, maximum ratio of dlog(chi2)/dlog(alpha) at the lowest alpha and the maximum value:"},
	{F_ALPHA_MIN,"f_alpha_min, factor by which alpha_min is reduced when found to be too high:"},
	{SAVE_ALPHA_RANGE,"save_alpha_range, range of alpha to be saved around the optimal alpha in log10 scale:"},
	{R_PEAK_WIDTH_DW, "R_peak_width_dw, ratio of low energy peak width and low frequency step:"},
	{R_WNCUTOFF_WR, "R_wncutoff_wr, ratio of onset Matsubara frequency of asymptotic region and main spectral range maximum frequency:"},
	{R_DW_DW, "R_Dw_dw, ratio of grid interval length and step:"},
	{R_SW_WR, "R_SW_wr, ratio of main spectral range maximum frequency and spectrum standard deviation:"},
	{R_WMAX_WR_MIN, "R_wmax_wr_min, minimum ratio of grid maximum frequency and main spectral range maximum frequency:"}} );
//{R_D2G_CHI_PEAK,"R_d2G_chi_peak, for bosons, ratio that determines if searching for low frequency peak:"},
//{TOL_R_G0_BETA,"tol_R_G0_Gbeta, tolerance on G(0)+G(beta)+1:"},
//{TOL_QUAD,"tol_quad, adaptive integration tolerance:"},
//{F_CHI2_SAVE,"f_chi2save, ratio of chi2 and the number of terms in its sum below which the spectral function is saved:"},
//{F_CHI2_MIN,"f_chi2min, minimum ratio of chi2 and the number of terms in its sum:"},
//{F_WIDTH_GRID_DENS,"f_width_grid_dens, width of grid density high frequency part with respect to spectral function width:"},

static map<Other_params_fl_name, double> Other_params_fl_default_values( {
	{F_SW_STD_OMEGA,3},
	{F_W_RANGE,20.0},
	{RMIN_SW_DW,25},
    {TOL_TEM,1.0e-8},
	{TOL_GINF,1.0e-3},
    {TOL_NORM,0.1},
    {TOL_M1,0.05},
    {TOL_M2,0.05},
    {TOL_M3,0.1},
    {DEFAULT_ERROR_G,1.0e-4},
    {ERR_NORM,1.0e-6},
    {DEFAULT_ERROR_M,1.0e-4},
    {TOL_MEAN_C1,0.001},
    {TOL_STD_C1,0.01},
    {TOL_RDW,1.0e-10},
    {RMIN_DW_DW,4.0},
    {RDW_MAX,5.0},
    {RW_GRID,5.0},
    {RWD_GRID,10.0},
    {MIN_DEF_M,1.0e-20},
    {F_ALPHA_INIT,1.0e3},
    {R_WIDTH_ASMIN,0.05},
    {F_SMIN,1.0},
    {DIFF_CHI2_MAX,0.1},
    {TOL_INT_DA,1.0e-12},
    {R_C2_H,1.0e12},
    {F_C2,1.0e20},
    {POW_ALPHA_STEP_INIT,0.2},
    {POW_ALPHA_STEP_MIN,0.001},
    {CHI2_ALPHA_SMOOTH_RANGE_2,0.2},
    {F_SCALE_LALPHA_LCHI2,0.2},
    {FN_FIT_TAU_W,4.0},
    {STD_NORM_PEAK_MAX,0.01},
    {VAR_M2_PEAK_MAX,0.01},
	{PEAK_WEIGHT_MIN,1.0e-4},
	{RMAX_DLCHI2_LALPHA,0.01},
	{F_ALPHA_MIN,100},
	{SAVE_ALPHA_RANGE,1},
	{R_PEAK_WIDTH_DW,10},
	{R_WNCUTOFF_WR,10},
	{R_DW_DW,20},
	{R_SW_WR,1},
	{R_WMAX_WR_MIN,3}} );
//{R_D2G_CHI_PEAK,0.1}, {TOL_R_G0_BETA,1.0e-8}, {TOL_QUAD,1.0e-10}, {F_CHI2_SAVE,1.0e3}, {F_CHI2_MIN,1.0e-6}, {F_WIDTH_GRID_DENS,1},

static const char *OmegaMaxEnt_notice=R"(
OmegaMaxEnt Copyright (C) 2015 Dominic Bergeron (dominic.bergeron@usherbrooke.ca)
This program comes with ABSOLUTELY NO WARRANTY; This is free software, and you
are welcome to redistribute it under certain conditions; For details refer to
the GNU General Public License, of which you should have received a copy
along with the program, or see <http://www.gnu.org/licenses/>.
)";

extern "C++"
{
	class OmegaMaxEnt_data: public generique
    {
    public:
        OmegaMaxEnt_data(int arg_N, char *args[]);
        ~OmegaMaxEnt_data();
        
        void loop_run();
		void display_license();
		void display_notice();
        
    private:
        
        bool load_input_params();
        bool load_other_params();
		bool load_data_file(mat &data_array, string file_name);
		bool preproc();
		bool set_G_omega_n_fermions();
		bool set_G_omega_n_bosons();
		bool set_covar_G_omega_n();
		bool set_covar_chi_omega_n();
		bool set_covar_Gtau();
		bool set_moments_fermions();
		bool set_moments_bosons();
		bool compute_moments_omega_n();
		bool compute_moments_omega_n_2();
		bool compute_moments_chi_omega_n();
		bool compute_moments_tau_fermions();
		bool compute_moments_tau_bosons();
		bool test_low_energy_peak_fermions();
		bool test_low_energy_peak_bosons();
		bool test_low_energy_peak_chi();
		bool set_initial_spectrum();
		bool set_initial_spectrum_chi();
		bool set_grid_omega_from_file();
		bool set_grid_omega_from_file_chi();
		bool set_grid_from_params();
		bool set_grid_from_params_chi();
		bool set_wc();
		bool set_wc_chi();
		bool set_omega_grid();
		bool set_omega_grid_chi();
		bool set_smooth_step_grid();
		bool set_quad_step_grid();
		bool set_exp_step_grid();
		bool set_A_ref();
		bool truncate_G_omega_n();
		bool truncate_chi_omega_n();
		bool set_default_model();
		bool set_default_model_chi();
		bool default_model_val_G(vec x, vec x0, vec coeffs, vec gaussians_params, vec &dm);
		bool default_model_val_chi(vec x, vec x0, vec coeffs, vec gaussians_params, vec &dm);
		bool Kernel_G_fermions();
		bool Kernel_G_fermions_grid_transf();
		bool Kernel_G_fermions_grid_transf_1();
		bool Kernel_G_fermions_grid_transf_omega();
		bool Kernel_G_bosons();
		bool Kernel_chi();
		bool diagonalize_covariance();
		bool diagonalize_covariance_chi();
		bool Fourier_transform_G_tau();
		
		bool non_uniform_frequency_grid(rowvec w_steps, rowvec wlims, double w0, vec R, vec &grid);
		void spline_coeffs_rel(double *x0, double *V, int N0, double *coeffs);
		bool spline_val(vec x, vec x0, vec coeffs, vec &s);
		bool sum_gaussians(vec x, rowvec x0, rowvec s0, rowvec wgt, vec &F);
		bool sum_gaussians_chi(vec x, rowvec x0, rowvec s0, rowvec wgt, vec &F);
		bool general_normal(vec x, double x0, double s0, double p, vec &F);
		double general_normal_val(double x, void *par[]);
		bool spline_G_part(vec x, uvec ind_xlims, vec xs, vec F, vec &coeffs);
		bool spline_G_omega_u(vec x, uvec ind_xlims, vec xs, vec F, vec &coeffs);
		bool spline_matrix_G_part(vec x, uvec ind_xlims, vec xs, mat &M);
		bool spline_matrix_grid_transf(vec w0, mat &M);
		bool spline_matrix_grid_transf_G_part(vec x, uvec ind_xlims, vec xs, mat &M);
		bool spline_matrix_grid_transf_G_part_1(vec x, uvec ind_xlims, vec xs, mat &M);
		bool spline_val_grid_transf(vec x, vec x0, vec coeffs, vec &s);
		bool spline_chi_part(vec x, uvec ind_xlims, vec xs, vec F, vec &coeffs);
		bool spline_matrix_chi(vec x, uvec ind_xlims, vec xs, mat &M);
		bool spline_val_G_part(vec x, vec x0, uvec ind_xlims, vec xs, vec coeffs, vec &sv);
		bool spline_val_G_part_grid_transf(vec x, vec x0, uvec ind_xlims, vec xs, vec coeffs, vec &sv);
		bool spline_val_G_part_grid_transf_1(vec x, vec x0, uvec ind_xlims, vec xs, vec coeffs, vec &sv);
		bool spline_val_chi_part(vec x, vec x0, uvec ind_xlims, vec xs, vec coeffs, vec &sv);
		double spline_val_G_part(double x, vec &x0, uvec &ind_xlims, vec &xs, vec &coeffs);
		bool fit_circle_arc(vec x, vec y, vec &arc_params);
		
		void minimize();
		void minimize_increase_alpha();
		
		double spline_val_G_part_int(double x, void *par[]);
		
		void plot(graph_2D &g, vec x, vec y, char *xl, char *yl, char *attr=NULL);
        
        bool create_default_input_params_file();
        bool create_default_other_params_file();
		
        void init_variables();
        void free_variables();
        
        string input_params_file_name;
        string other_params_file_name;
        
        //! internal computation parameters
        int Nn_max, Nw_min, Nw_max, Nn_fit_max, Nn_fit_fin, Niter_dA_max, Nalpha_max_figs, Nwsamp;
        double f_w_range, f_SW_std_omega, f_width_grid_dens, tol_tem, tol_G_inf, tol_norm, tol_R_G0_Gbeta, tol_M1, tol_M2, tol_M3, default_error_G, err_norm, default_error_M, tol_mean_C1, tol_std_C1, tol_rdw, Rmin_Dw_dw, Rdw_max, RW_grid, RWD_grid, minDefM, f_alpha_init, R_width_ASmin, f_Smin, diff_chi2_max, tol_int_dA, rc2H, fc2, pow_alpha_step_init, pow_alpha_step_min, chi2_alpha_smooth_range, f_scale_lalpha_lchi2, FNfitTauW, std_norm_peak_max, varM2_peak_max, peak_weight_min, RMAX_dlchi2_lalpha, f_alpha_min, save_alpha_range,  Rmin_SW_dw, R_peak_width_dw, R_wncutoff_wr, R_Dw_dw, R_SW_wr, R_wmax_wr_min;
        //tol_quad, f_chi2save, f_chi2min, Nwn_test_metal, R_d2G_chi_peak,
        
        //! input parameters
        string input_dir_in, *input_dir_prec, input_dir, data_file_name_in, *data_file_name_prec, data_file_name, boson_in, *boson_prec, tau_GF_in, *tau_GF_prec, tem_in, *tem_prec, M0_in, *M0_prec, M1_in, *M1_prec, errM1_in, *errM1_prec, M2_in, *M2_prec, errM2_in, *errM2_prec, M3_in, *M3_prec, errM3_in, *errM3_prec, omega_n_trunc_in, *omega_n_trunc_prec, G_omega_inf_in, *G_omega_inf_prec, col_Gr_in, *col_Gr_prec, col_Gi_in, *col_Gi_prec, error_file_in, *error_file_prec, error_file, col_errGr_in, *col_errGr_prec, col_errGi_in, *col_errGi_prec, covar_re_re_file_in, *covar_re_re_file_prec, covar_re_re_file, covar_im_im_file_in, *covar_im_im_file_prec, covar_im_im_file, covar_re_im_file_in, *covar_re_im_file_prec, covar_re_im_file, col_Gtau_in, *col_Gtau_prec, col_errGtau_in, *col_errGtau_prec, covar_tau_file_in, *covar_tau_file_prec, covar_tau_file, cutoff_wn_in, *cutoff_wn_prec, SW_in, *SW_prec, SC_in, *SC_prec, w_origin_in, *w_origin_prec, step_omega_in, *step_omega_prec, grid_omega_file_in, *grid_omega_file_prec, grid_omega_file, use_grid_params_in, *use_grid_params_prec, omega_grid_params_in, *omega_grid_params_prec, eval_moments_in, *eval_moments_prec, maxM_in, *maxM_prec, def_model_file_in, *def_model_file_prec, def_model_file, init_spectr_func_file_in, *init_spectr_func_file_prec, init_spectr_func_file, interp_type_in, *interp_type_prec, default_model_center_in, *default_model_center_prec, default_model_width_in, *default_model_width_prec, default_model_shape_in, *default_model_shape_prec, non_uniform_grid_in, *non_uniform_grid_prec, Ginf_finite_in, *Ginf_finite_prec;
		//peaked_default_model_in, *peaked_default_model_prec,
		
        bool use_grid_params, use_const_dw, use_exp_step, displ_prep_figs, displ_adv_prep_figs, print_other_params, boson, tau_GF, initialize, initialize_maxent, execute_maxent, save_spec_func, print_alpha, displ_optim_figs, cov_diag, moments_provided, eval_moments, covm_diag, wc_exists, w_exists, SW_set, SC_set, peak_exists, read_params, read_other_params, params_loaded, other_params_loaded, M1_set, M2_set, main_spectral_region_set, A_ref_change, show_optimal_alpha_figs, show_lowest_alpha_figs, show_alpha_curves, preproc_complete, Du_constant, non_uniform_grid, w_origin_set, interactive_mode, Ginf_finite;
		//peaked_default_model, save_Aopt_only,
        
        string interp_type, output_dir_in, output_dir, output_dir_fin, *output_dir_prec, output_name_suffix, output_name_format, w_sample_in, *w_sample_prec, Nalpha_in, alpha_min_in, alpha_init_in, alpha_opt_max_in, alpha_opt_min_in, *alpha_init_prec, alpha_save_max_in, alpha_save_min_in, A_ref_file, A_ref_file_in, *A_ref_file_prec, def_model_output_file_name, A_opt_name_format, A_opt_err_name_format, output_G_format, output_error_format, auto_corr_error_G_format, output_G_opt_format, error_G_opt_format, auto_corr_error_G_opt_format, output_moments_format, output_moments_opt_format, chi2_vs_alpha_format, Asamp_vs_alpha_format, A_opt_name_rm, A_opt_err_name_rm, output_G_opt_rm, error_G_opt_rm, auto_corr_error_G_opt_rm, output_moments_opt_rm;
		//alpha_save_in,
		
        double tem, cutoff_wn, SW, SC, w_origin, step_omega, signG, alpha0, alpha0_default, alpha, pow_alpha_step, alpha_min_default, alpha_min, alpha_opt_max, alpha_opt_min, M0, errM0, M1, errM1, M2, errM2, M3, errM3, std_omega, omega_n_trunc, wl, wr, w0l, w0r, dwl, dwr, dw_peak, M0t, M1n, default_model_width, default_model_center, default_model_shape, dlchi2_lalpha_min, dlchi2_lalpha_max, alpha_save_max, alpha_save_min, lchi2_lalpha_lgth, G_omega_inf;
		//chi2save, chi2min, alpha_save,
        
        uint col_Gr, col_errGr, col_errGi, col_Gtau, col_errGtau, Nalpha, Nn, Nn_all, indG_0, indG_f, NM, NMinput, NM_odd, NM_even, Nw, NwA, Nwc, jfit, ind_cutoff_wn, NGM, Nalpha_max, NAprec, ind0, Ntau, Nn_as_min;
		uvec n, n_all, Nw_lims;
		int maxM, maxM_default, col_Gi, ind_alpha_vec, NnC, ind_curv, ind_curv0, Nn_min;
        
//        time_t *input_params_file_time, *other_params_file_time;
		
		mat K, KGM, KG_V, KM, KM_V, COV, CRR, CII, CRI, COVM, COVMfit, Ctau, Ctau_all, green_data, error_data, grid_w_data, def_data, Aw_data, Aref_data, Aprec, Aw_samp;
		//HK,
		rowvec omega_grid_params, w_sample;
		uvec w_sample_ind;
		vec Gr, Gi, Gchi2, G_V, GM, wn, wn_all, errGr, errGi, errG, errGtau, M, M_V, errM, M_even, M_odd, Mfit, ws, A, A0, Amin, wc, w, wA, dwS, default_model, w_ref, A_ref, chi2_vec, alpha_vec, S_vec, M_ord, Gtau, tau, dlchi2_lalpha_1, curv_lchi2_lalpha_1, grid_dens;
		cx_vec G, G_all;
		cx_mat Kcx;
		
		bool wn_sign_change, wn_inversed;
		
//		QDateTime *time_params_file, *time_other_params_file;
		
		time_t *time_params_file, *time_other_params_file;

    };
    
}

#endif
